<?php


namespace App\Repositories\HT20;


use App\Repositories\RepositoryInterface;

interface ApartmentRepository extends RepositoryInterface
{

}
