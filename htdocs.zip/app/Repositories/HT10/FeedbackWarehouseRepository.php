<?php


namespace App\Repositories\HT10;


use App\Repositories\RepositoryInterface;

interface FeedbackWarehouseRepository extends RepositoryInterface
{

}
