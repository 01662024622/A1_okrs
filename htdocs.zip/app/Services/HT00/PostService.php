<?php

namespace App\Services\HT00;

use App\Services\ServiceInterface;

interface PostService extends ServiceInterface
{
    //
}