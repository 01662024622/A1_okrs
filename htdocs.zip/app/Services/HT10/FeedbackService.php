<?php
namespace App\Services\HT10;

use App\Services\ServiceInterface;

interface FeedbackService extends ServiceInterface
{

}
