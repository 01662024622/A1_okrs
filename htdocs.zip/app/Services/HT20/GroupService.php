<?php

namespace App\Services\HT20;

use App\Services\ServiceInterface;

interface GroupService extends ServiceInterface
{
    //
}